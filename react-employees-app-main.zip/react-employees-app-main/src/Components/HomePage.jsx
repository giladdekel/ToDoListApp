import React from 'react'

export default function HomePage(props) {
    return (
        <div>
            <h1 className="font-weight-bold">Home</h1>
            <p>Welcome to our Employees app</p>
        </div>
    )
}
